// src/routes/uploads.js
import express from "express";
import multer from "multer";
import cloudinary from "../config/cloudinary.js";

const router = express.Router();

// memory storage, Multer will NOT save to disk
const upload = multer({ storage: multer.memoryStorage() });

router.post("/audio", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    // convert file buffer to base64
    const base64 = `data:audio/webm;base64,${req.file.buffer.toString("base64")}`;

    // upload to cloudinary
    const result = await cloudinary.uploader.upload(base64, {
      folder: "serviconnect_audio",
      resource_type: "video",        // IMPORTANT: audio files must use video type
      format: "webm",
    });

    return res.json({ audioUrl: result.secure_url });
  } catch (err) {
    console.error("Cloudinary upload error:", err);
    return res.status(500).json({ error: "Upload failed" });
  }
});

export default router;
