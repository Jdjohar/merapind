# ServiConnect Backend

## Setup
1. Copy `.env.example` to `.env` and fill values (MONGO_URI, JWT_SECRET, EMAIL_*).
2. Install packages:
   ```bash
   npm install
