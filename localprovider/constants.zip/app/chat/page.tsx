// app/chat/page.tsx
'use client';

import React, { useEffect, useRef, useState } from 'react';
import io, { Socket } from 'socket.io-client';
import { Send, Mic, X } from 'lucide-react';
import { useSearchParams } from 'next/navigation';

type ServerMsg = {
  _id?: string;
  chatId?: string;
  senderId: string;
  text?: string;
  audioUrl?: string;
  createdAt?: string;
};

type UIMessage = {
  id: string;
  senderId: string;
  text?: string;
  audioUrl?: string;
  timestamp: string;
  isMe: boolean;
};

const BACKEND = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:5000';

let socket: Socket | null = null;

export default function ChatPage() {
  const searchParams = useSearchParams();
  const providerId = (searchParams?.get('providerId') as string) || '';
  const [chat, setChat] = useState<{ _id: string } | null>(null);
  const [messages, setMessages] = useState<UIMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;

  const getMyUserIdFromToken = (): string | null => {
    try {
      if (!token) return null;
      const p = token.split('.')[1];
      if (!p) return null;
      const payload = JSON.parse(atob(p));
      return payload.id || payload._id || null;
    } catch {
      return null;
    }
  };

  const convertServerMsg = (m: ServerMsg): UIMessage => ({
    id: m._id ?? `${Math.random().toString(36).slice(2)}`,
    senderId: m.senderId,
    text: m.text,
    audioUrl: m.audioUrl,
    timestamp: m.createdAt ?? new Date().toISOString(),
    isMe: getMyUserIdFromToken() === m.senderId
  });

  // Initialize socket once
  useEffect(() => {
    if (socket) return;

    socket = io(BACKEND, {
      transports: ['websocket'],
      auth: { token }
    });

    socket.on('connect', () => {
      console.log('socket connected', socket?.id);
    });

    // Server broadcast when message saved: 'receive_message'
    socket.on('receive_message', (msg: ServerMsg) => {
      setMessages(prev => {
        // prevent duplicates: if we already have message id, skip
        if (msg._id && prev.some(m => m.id === msg._id)) return prev;
        return [...prev, convertServerMsg(msg)];
      });
      scrollToBottom();
    });

    socket.on('connect_error', (err: any) => {
      console.warn('socket connect_error', err);
    });

    socket.on('disconnect', (reason) => {
      console.log('socket disconnected', reason);
    });

    // cleanup if component unmounts and you want to disconnect:
    return () => {
      // keep socket alive if you want multi-page reuse; otherwise disconnect:
      // socket?.disconnect();
      // socket = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // open/create chat when providerId is available
  useEffect(() => {
    if (!providerId) return;

    let mounted = true;

    (async () => {
      try {
        const res = await fetch(`${BACKEND}/api/chats/get-or-create`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: token ? `Bearer ${token}` : ''
          },
          body: JSON.stringify({ providerId })
        });

        if (!res.ok) {
          const txt = await res.text();
          console.error('open chat failed', res.status, txt);
          return;
        }

        const data = await res.json();
        if (!mounted) return;
        const chatId = data._id ?? data.id;
        setChat({ _id: chatId });

        // fetch existing messages
        const msgsRes = await fetch(`${BACKEND}/api/chats/${chatId}/messages`, {
          headers: { Authorization: token ? `Bearer ${token}` : '' }
        });

        if (msgsRes.ok) {
          const msgs: ServerMsg[] = await msgsRes.json();
          setMessages(msgs.map(convertServerMsg));
          scrollToBottom();
        } else {
          console.warn('Could not fetch messages', msgsRes.status);
        }

        // join socket room for realtime updates
        if (socket && chatId) {
          socket.emit('join_chat', chatId);
        }
      } catch (err) {
        console.error('openChat error', err);
      }
    })();

    return () => {
      mounted = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [providerId]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSend = async () => {
    if (!inputText.trim()) return;
    if (!chat) {
      console.warn('no chat created yet');
      return;
    }
    const chatId = chat._id;
    const payload = { text: inputText };

    try {
      const res = await fetch(`${BACKEND}/api/chats/${chatId}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: token ? `Bearer ${token}` : ''
        },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const txt = await res.text();
        console.error('send failed', res.status, txt);
        return;
      }

      const saved: ServerMsg = await res.json();

      // If socket is connected, server will broadcast `receive_message` to the room
      // so do NOT double-insert. If socket is not connected, append locally.
      if (!socket || socket.disconnected) {
        setMessages(prev => [...prev, convertServerMsg(saved)]);
      }

      setInputText('');
      scrollToBottom();

      // Also emit via socket for real-time clients that prefer socket-originated flow.
      // (Server will likely broadcast again; server should dedupe or clients guard duplicates by id)
      socket?.emit('send_message', {
        chatId,
        senderId: getMyUserIdFromToken(),
        text: saved.text,
        _temp: true // optional flag; server ignores
      });
    } catch (err) {
      console.error('send error', err);
    }
  };

  const uploadAudioBlob = async (blob: Blob) => {
    const form = new FormData();
    form.append('file', blob, 'voice.webm');

    const resp = await fetch(`${BACKEND}/api/uploads/audio`, {
      method: 'POST',
      body: form,
      headers: {
        Authorization: token ? `Bearer ${token}` : ''
      }
    });

    if (!resp.ok) {
      const txt = await resp.text();
      throw new Error(`upload failed: ${resp.status} ${txt}`);
    }

    return (await resp.json()).audioUrl as string;
  };

  const handleRecordToggle = async () => {
    if (isRecording) {
      mediaRecorder?.stop();
      setIsRecording(false);
      return;
    }

    if (!navigator.mediaDevices?.getUserMedia) {
      alert('Recording not supported in this browser');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      setMediaRecorder(mr);
      chunksRef.current = [];

      mr.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunksRef.current.push(e.data);
      };

      mr.onstop = async () => {
        try {
          const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
          const audioUrl = await uploadAudioBlob(blob);

          if (!chat) return;
          const chatId = chat._id;

          const res = await fetch(`${BACKEND}/api/chats/${chatId}/messages`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: token ? `Bearer ${token}` : ''
            },
            body: JSON.stringify({ audioUrl })
          });

          if (!res.ok) {
            const txt = await res.text();
            console.error('audio message save failed', res.status, txt);
            return;
          }

          const saved: ServerMsg = await res.json();

          // same duplicate-avoidance logic
          if (!socket || socket.disconnected) {
            setMessages(prev => [...prev, convertServerMsg(saved)]);
          }

          socket?.emit('send_message', {
            chatId,
            senderId: getMyUserIdFromToken(),
            audioUrl: saved.audioUrl
          });

          scrollToBottom();
        } catch (err) {
          console.error('upload/send audio failed', err);
        }
      };

      mr.start();
      setIsRecording(true);
    } catch (err) {
      console.error('record start failed', err);
      alert('Could not start recording: ' + String(err));
    }
  };

  return (
    <div className="h-[calc(100vh-64px)] bg-gray-100 flex">
      <div className="hidden md:flex flex-col w-80 bg-white border-r border-gray-200">
        <div className="p-4 border-b">
          <h2 className="text-xl font-bold">Messages</h2>
        </div>
      </div>

      <div className="flex-1 flex flex-col bg-gray-50">
        <div className="bg-white h-16 border-b px-4 flex items-center justify-between">
          <div>
            <h3 className="font-bold">Chat</h3>
            <div className="text-xs text-gray-500">{providerId ? `Provider: ${providerId}` : 'No provider'}</div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.isMe ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[75%] rounded-2xl px-4 py-3 shadow-sm ${msg.isMe ? 'bg-blue-600 text-white' : 'bg-white text-gray-900 border border-gray-200'}`}>
                {msg.audioUrl ? (
                  <div className="min-w-[150px]">
                    <audio controls src={msg.audioUrl} />
                  </div>
                ) : (
                  <p className="whitespace-pre-wrap">{msg.text}</p>
                )}
                <div className="text-[10px] mt-1 text-right text-gray-400">{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        <div className="bg-white p-4 border-t">
          {isRecording ? (
            <div className="flex items-center justify-between bg-red-50 text-red-600 px-4 py-3 rounded-lg">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-600 rounded-full animate-pulse" />
                <span className="font-bold">Recording...</span>
              </div>
              <button onClick={handleRecordToggle} className="bg-white p-2 rounded-full shadow">
                <X className="w-5 h-5 text-red-600" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={inputText}
                onChange={e => setInputText(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSend()}
                placeholder="Type a message..."
                className="flex-1 px-4 py-2 rounded-full bg-gray-100 outline-none"
              />
              {inputText.trim() ? (
                <button onClick={handleSend} className="p-3 bg-blue-600 text-white rounded-full">
                  <Send className="w-5 h-5" />
                </button>
              ) : (
                <button onClick={handleRecordToggle} className="p-3 bg-gray-200 rounded-full">
                  <Mic className="w-5 h-5" />
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
