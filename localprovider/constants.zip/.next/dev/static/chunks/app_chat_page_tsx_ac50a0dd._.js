(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_bb18acd8._.js",
  "static/chunks/app_chat_page_tsx_9f2a1abf._.js"
],
    source: "dynamic"
});
