(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_876da7ca._.js",
  "static/chunks/_dc0265d3._.js"
],
    source: "dynamic"
});
