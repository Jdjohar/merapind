(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_c7b96e4c._.js",
  "static/chunks/_162d1a5f._.js"
],
    source: "dynamic"
});
