module.exports = [
"[project]/.next-internal/server/app/chat/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_chat_page_actions_c92d15a6.js.map