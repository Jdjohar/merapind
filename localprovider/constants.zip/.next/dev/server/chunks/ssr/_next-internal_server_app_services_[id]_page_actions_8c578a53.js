module.exports = [
"[project]/.next-internal/server/app/services/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_services_%5Bid%5D_page_actions_8c578a53.js.map