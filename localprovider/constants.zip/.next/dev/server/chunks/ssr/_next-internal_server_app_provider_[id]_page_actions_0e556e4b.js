module.exports = [
"[project]/.next-internal/server/app/provider/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_provider_%5Bid%5D_page_actions_0e556e4b.js.map