module.exports = [
"[project]/.next-internal/server/app/provider/services/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_provider_services_page_actions_f7b112a9.js.map