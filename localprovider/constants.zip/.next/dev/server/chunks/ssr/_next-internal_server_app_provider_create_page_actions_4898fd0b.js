module.exports = [
"[project]/.next-internal/server/app/provider/create/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_provider_create_page_actions_4898fd0b.js.map